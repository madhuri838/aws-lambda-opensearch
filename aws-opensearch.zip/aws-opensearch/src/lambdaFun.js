import * as boto3 from 'boto3';
import * as json from 'json';
import * as requests from 'requests';
import { AWS4Auth } from 'requests_aws4auth';
var awsauth, credentials, host, index, region, service, url;
region = "";
service = "es";
credentials = new boto3.Session().get_credentials();
awsauth = new AWS4Auth(credentials.access_key, credentials.secret_key, region, service, {
  "session_token": credentials.token
});
host = "";
index = "movies";
url = host + "/" + index + "/_search";

function lambda_handler(event, context) {
  var headers, query, r, response;
  query = {
    "size": 25,
    "query": {
      "multi_match": {
        "query": event["queryStringParameters"]["q"],
        "fields": ["title^4", "plot^2", "actors", "directors"]
      }
    }
  };
  headers = {
    "Content-Type": "application/json"
  };
  r = requests.get(url, {
    "auth": awsauth,
    "headers": headers,
    "data": json.dumps(query)
  });
  response = {
    "statusCode": 200,
    "headers": {
      "Access-Control-Allow-Origin": "*"
    },
    "isBase64Encoded": false
  };
  response["body"] = r.text;
  return response;
}
